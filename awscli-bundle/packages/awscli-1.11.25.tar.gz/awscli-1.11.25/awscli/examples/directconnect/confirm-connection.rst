**To confirm the creation of a hosted connection on an interconnect**

The following ``confirm-connection`` command confirms the creation of a hosted connection on an interconnect::

  aws directconnect confirm-connection --connection-id dxcon-fg2wi7hy

Output::

  {
      "connectionState": "pending"
  }
